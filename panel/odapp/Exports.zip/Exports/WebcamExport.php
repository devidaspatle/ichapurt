<?php

namespace App\Exports;

use App\Webcam;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\WithHeadings;

class WebcamExport implements FromCollection,WithHeadings
{
     public function headings():array{
        return[
        	'id',
            'make',
            'model',
            'serial_number',
            'txtcondition',
            'created_at',
            'status'
        ];
    } 
    public function collection()
    {
        return Webcam::all();
    }
}

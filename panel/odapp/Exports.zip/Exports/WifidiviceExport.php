<?php

namespace App\Exports;

use App\Wifidivice;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\WithHeadings;

class WifidiviceExport implements FromCollection
{
      public function headings():array{
        return[
        	'id',
            'make',
            'model',
            'serial_number',
            'txtcondition',
            'created_at',
            'status'
        ];
    } 
    public function collection()
    {
        return Wifidivice::all();
    }
}

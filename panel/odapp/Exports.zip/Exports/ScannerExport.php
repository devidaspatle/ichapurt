<?php

namespace App\Exports;

use App\Scanner;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\WithHeadings;

class ScannerExport implements FromCollection,WithHeadings
{
     public function headings():array{
        return[
        	'id',
            'make',
            'model',
            'serial_number',
            'scanner_type',
            'txtcondition',
            'created_at',
            'status'
        ];
    } 
    public function collection()
    {
        return Scanner::all();
    }
}
